import os, json, time, math, hashlib, pathlib
from typing import List, Dict

from .pdf_utils import try_extract_text
from .chunking import split_into_chunks, is_heading_like
from .labeling import classify_chunk
from .prompts import QA_SYSTEM, QA_USER
from .models import set_api_key_for_process, call_json_chat, count_tokens_rough
from .export import export_to_excel
from .config import load_config
from .logging_utils import get_logger

def sha256(text: str) -> str:
    import hashlib
    return hashlib.sha256(text.encode("utf-8")).hexdigest()

class Pipeline:
    def __init__(self, api_key: str, qa_model: str, label_model: str, use_cache: bool, budget_usd: float, limit_by_budget: bool, questions_per_chunk: int, ui_logger=None, ui_progress=None, ui_status=None):
        self.api_key = api_key
        self.qa_model = qa_model
        self.label_model = label_model
        self.use_cache = use_cache
        self.budget_usd = budget_usd
        self.limit_by_budget = limit_by_budget
        self.questions_per_chunk = max(1, int(questions_per_chunk))
        self.cfg = load_config()
        self.log = get_logger()
        self.ui_logger = ui_logger or (lambda s: None)
        self.ui_progress = ui_progress or (lambda v: None)
        self.ui_status = ui_status or (lambda s: None)

    def run(self, path: str, out_dir: str):
        set_api_key_for_process(self.api_key)
        raw = try_extract_text(path)
        if not raw.strip():
            raise RuntimeError("Kein Text extrahiert. Prüfen Sie die Datei.")

        chunks = split_into_chunks(raw, self.cfg["chunking"]["target_tokens"], self.cfg["chunking"]["overlap_tokens"], self.cfg["chunking"]["max_chars_per_chunk"])
        self.ui_logger(f"[INFO] {len(chunks)} Chunks erzeugt.")
        cache_dir = pathlib.Path(".cache"); cache_dir.mkdir(exist_ok=True)

        # ggf. Budget-Anpassung
        q_per_chunk = self.questions_per_chunk
        if self.limit_by_budget and self.budget_usd > 0:
            from .cost import estimate_cost_for_text
            est = estimate_cost_for_text(raw, model=self.qa_model, label_model=self.label_model, questions_per_chunk=q_per_chunk)
            self.ui_logger(f"[BUDGET] Erwartete Kosten ≈ ${est['total_cost_usd']:.4f} bei {q_per_chunk} Fragen/Chunk.")
            if est["total_cost_usd"] > self.budget_usd:
                factor = max(0.25, self.budget_usd / max(est["total_cost_usd"], 1e-6))
                scaled = max(1, int(round(q_per_chunk * factor)))
                self.ui_logger(f"[BUDGET] Skaliere Fragen/Chunk von {q_per_chunk} → {scaled}.")
                q_per_chunk = scaled

        rows = []
        total = len(chunks)
        for i, chunk in enumerate(chunks, start=1):
            self.ui_status(f"Segment {i}/{total}")
            self.ui_progress(i * 100.0 / total)

            # 1) Heuristische Meta-Erkennung (kostenlos)
            if _looks_meta(chunk):
                self.ui_logger(f"[{i}/{total}] Heuristisch als META erkannt – übersprungen.")
                continue

            # 2) Nano-Labeling
            cache_key = sha256("LBL|" + chunk + "|" + self.label_model)
            lbl_path = cache_dir / f"{cache_key}.label.json"
            if self.use_cache and lbl_path.exists():
                with open(lbl_path, "r", encoding="utf-8") as f:
                    label = json.load(f)
            else:
                label = classify_chunk(chunk, self.label_model)
                with open(lbl_path, "w", encoding="utf-8") as f:
                    json.dump(label, f, ensure_ascii=False, indent=2)

            if label.get("is_meta") or not label.get("has_questions", True):
                self.ui_logger(f"[{i}/{total}] LLM: META/ohne Fragen – übersprungen ({label.get('content_type')}).")
                continue

            # 3) Fragen/Ausgabe
            q_cache_key = sha256("QA|" + chunk + "|" + self.qa_model + f"|{q_per_chunk}")
            qa_path = cache_dir / f"{q_cache_key}.qa.json"
            if self.use_cache and qa_path.exists():
                with open(qa_path, "r", encoding="utf-8") as f:
                    qa = json.load(f)
            else:
                user_prompt = QA_USER.format(n=q_per_chunk, chunk=chunk)
                qa = call_json_chat(model=self.qa_model, system_prompt=QA_SYSTEM, user_prompt=user_prompt, temperature=0.2, max_output_tokens=2000)
                with open(qa_path, "w", encoding="utf-8") as f:
                    json.dump(qa, f, ensure_ascii=False, indent=2)

            data = qa.get("data", {})
            questions = data.get("questions", [])
            for q in questions:
                rows.append([chunk, q.get("q",""), q.get("a",""), label.get("content_type",""), f"Segment {i}/{total}"])

        if not rows:
            raise RuntimeError("Keine Lernkarten erzeugt. Prüfen Sie Labeling/Filter und Inhalt.")

        xlsx = export_to_excel(rows, out_dir, base_name="gsa_flashcards")
        self.ui_logger(f"[OK] Export: {xlsx}")
        return xlsx

def _looks_meta(text: str) -> bool:
    # Schnelle Vorfilterung: sehr kurze Blöcke, viele Großbuchstaben, typische Meta-Begriffe
    t = text.strip()
    if len(t.split()) < 4:
        return True
    meta_kw = ["literatur", "abbildungsverzeichnis", "inhalt", "dank", "vorwort", "kontakt", "hilfe & kontakt", "faq"]
    low = t.lower()
    if any(k in low for k in meta_kw):
        return True
    # Viele sehr kurze Zeilen
    short_lines = sum(1 for l in t.splitlines() if len(l.strip()) <= 3)
    if short_lines >= 3:
        return True
    return False
