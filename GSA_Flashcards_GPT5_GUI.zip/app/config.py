import os, toml, pathlib

def load_config():
    here = pathlib.Path(__file__).resolve().parent.parent
    cfg_path = here / "config.toml"
    if not cfg_path.exists():
        # fallback: parent
        cfg_path = pathlib.Path("config.toml")
    if cfg_path.exists():
        return toml.load(cfg_path)
    # defaults
    return {
        "models": {"label_model":"gpt-5-nano","qa_model":"gpt-5","use_json_mode": True, "max_parallel_requests":3},
        "chunking": {"target_tokens":600,"overlap_tokens":60,"max_chars_per_chunk":4000},
        "prompting": {"language":"de","tone":"sachlich","max_questions_per_chunk_default":8},
        "costs": {},
        "ui": {"theme":"auto"}
    }
